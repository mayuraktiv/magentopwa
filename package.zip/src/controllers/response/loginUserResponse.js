const loginUserResponse = {};

loginUserResponse.parse = (res)=>{
    return console.log(res,"data")
}

export default loginUserResponse