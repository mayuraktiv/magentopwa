// import React from 'react';
// import PropTypes from 'prop-types';

// export default function Toolbar(props) {    
//     return (
//         <div className="toolbar">
//             <div className="modes">
//                 <button id="grid" className="product_grid_link" > 
//                     <span className="material-icons">view_module</span>
//                 </button>
//                 <button id="list" className="product_list_link"> 
//                     <span className="material-icons">view_list</span>
//                 </button>
//             </div>
//             <div className="toolbar-sorter">
//                 <div className="form-select">
//                     <select id="sorter" className="sorter-optio ns">
//                         <option value="position" selected="selected">Sort by Position</option>
//                         <option value="name">Sort by Product Name</option>
//                         <option value="price">Sort by Price</option>
//                         <option value="best_seller">Sort by Best Seller</option>
//                         <option value="featured">Sort by Featured</option>
//                         <option value="special">Sort by Special</option>
//                         <option value="lastest">Sort by Lastest</option>
//                     </select>
//                 </div>
//             </div>
//         </div>
//     )
// }

