const localStorageKeys = {
    AUTHORIZATION_TOKEN: 'authorizationToken'
}

export default localStorageKeys;