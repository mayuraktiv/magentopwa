import React from 'react';
const CategoryContext = React.createContext();
export default CategoryContext;