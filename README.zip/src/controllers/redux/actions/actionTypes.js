const actionTypes = {};

actionTypes.REPLACE = "REPLACE";
actionTypes.MERGE = "MERGE";
actionTypes.ADD = "ADD";
actionTypes.DELETE = "DELETE";

export default actionTypes;